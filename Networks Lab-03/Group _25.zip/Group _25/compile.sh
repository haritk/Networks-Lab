gcc -o c  client.c
gcc -o n -pthread NODE.c
gcc -o s fserver.c
